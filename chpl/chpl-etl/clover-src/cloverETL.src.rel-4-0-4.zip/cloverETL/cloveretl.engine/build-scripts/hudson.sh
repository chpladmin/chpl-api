#!/bin/sh

#groovy script wrapper

#export LC_CTYPE=en_US.UTF-8

/opt/groovy-1.7/bin/groovy cloveretl.engine/build-scripts/hudson.groovy
