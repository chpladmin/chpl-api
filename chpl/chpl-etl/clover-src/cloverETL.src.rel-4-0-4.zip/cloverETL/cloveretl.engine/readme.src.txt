CloverETL Engine version 0.0.0.devel
www.cloveretl.com
---------------------------------

Use Apache ANT to build binary - run with
"build.xml" from "cloveretl.engine/" dir. 

Before compilation, update "cloveretl.engine/build.properties" file
to reflect your set-up.

CloverETL requires Java version 1.6
All other required third party libraries can be found in "cloveretl.engine/lib/" directory.

These are:
commons-logging (Apache)- http://jakarta.apache.org/commons/logging/
log4j (Apache) 			- http://logging.apache.org/log4j/docs/
poi (Apache)			- http://jakarta.apache.org/poi/
jxl	(LGPL)				- http://jexcelapi.sourceforge.net/
jms	(as JDK)			- http://java.sun.com/products/jms/
javolution (BSD like)	- http://www.javolution.org/
commons-cli (Apache)	- http://jakarta.apache.org/commons/cli/
Saxon8 (MPL) 			- http://sourceforge.net/projects/saxon/
JSch (BSD-style)		- http://www.jcraft.com/jsch/
Janino (New BSD)		- http://www.janino.net/


Support
-------
In case you encounter issues running CloverETL Engine, please contact us at support@cloveretl.com
